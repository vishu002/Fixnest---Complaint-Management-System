package services;

import models.Complaint;
import com.cms.fixnest.config.DatabaseConfig;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComplaintService {
    
    public boolean createComplaint(Complaint complaint) {
        String sql = "INSERT INTO complaints (student_id, title, description, category) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, complaint.getStudentId());
            pstmt.setString(2, complaint.getTitle());
            pstmt.setString(3, complaint.getDescription());
            pstmt.setString(4, complaint.getCategory());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error creating complaint: " + e.getMessage());
            return false;
        }
    }
    
    public List<Complaint> getComplaintsByStudent(int studentId) {
        List<Complaint> complaints = new ArrayList<>();
        String sql = "SELECT c.*, u.full_name as student_name FROM complaints c " +
                    "JOIN users u ON c.student_id = u.id WHERE c.student_id = ? ORDER BY c.created_at DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                complaints.add(extractComplaintFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error fetching student complaints: " + e.getMessage());
        }
        
        return complaints;
    }
    
    public List<Complaint> getAllComplaints() {
        List<Complaint> complaints = new ArrayList<>();
        String sql = "SELECT c.*, u.full_name as student_name FROM complaints c " +
                    "JOIN users u ON c.student_id = u.id ORDER BY c.created_at DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                complaints.add(extractComplaintFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error fetching all complaints: " + e.getMessage());
        }
        
        return complaints;
    }
    
    public boolean updateComplaintStatus(int complaintId, Complaint.Status status, String adminNotes) {
        String sql = "UPDATE complaints SET status = ?, admin_notes = ?, resolved_at = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status.toString());
            pstmt.setString(2, adminNotes);
            
            if (status == Complaint.Status.RESOLVED) {
                pstmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            } else {
                pstmt.setNull(3, Types.TIMESTAMP);
            }
            
            pstmt.setInt(4, complaintId);
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating complaint status: " + e.getMessage());
            return false;
        }
    }
    
    private Complaint extractComplaintFromResultSet(ResultSet rs) throws SQLException {
        Complaint complaint = new Complaint();
        complaint.setId(rs.getInt("id"));
        complaint.setStudentId(rs.getInt("student_id"));
        complaint.setStudentName(rs.getString("student_name"));
        complaint.setTitle(rs.getString("title"));
        complaint.setDescription(rs.getString("description"));
        complaint.setCategory(rs.getString("category"));
        complaint.setStatus(Complaint.Status.valueOf(rs.getString("status")));
        complaint.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        
        Timestamp resolvedAt = rs.getTimestamp("resolved_at");
        if (resolvedAt != null) {
            complaint.setResolvedAt(resolvedAt.toLocalDateTime());
        }
        
        complaint.setAdminNotes(rs.getString("admin_notes"));
        return complaint;
    }
}