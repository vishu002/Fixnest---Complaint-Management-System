package models;

import java.time.LocalDateTime;

public class Complaint {
    private int id;
    private int studentId;
    private String studentName;
    private String title;
    private String description;
    private String category;
    private Status status;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;
    private String adminNotes;
    
    public enum Status {
        PENDING, IN_PROGRESS, RESOLVED
    }
    
    public Complaint() {}
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
    
    public String getAdminNotes() { return adminNotes; }
    public void setAdminNotes(String adminNotes) { this.adminNotes = adminNotes; }
    
    @Override
    public String toString() {
        return "Complaint{id=" + id + ", title='" + title + "', status=" + status + "}";
    }
}