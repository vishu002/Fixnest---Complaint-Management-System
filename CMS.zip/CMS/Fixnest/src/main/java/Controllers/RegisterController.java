package Controllers;

import models.User;
import services.UserService;
import utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterController {

    @FXML
    private TextField fullNameField;
    
    @FXML
    private TextField emailField;
    
    @FXML
    private TextField usernameField;
    
    @FXML
    private PasswordField passwordField;
    
    @FXML
    private PasswordField confirmPasswordField;
    
    @FXML
    private ComboBox<String> userTypeComboBox;
    
    @FXML
    private Label errorLabel;
    
    @FXML
    private Label successLabel;
    
    private UserService userService;
    
    public RegisterController() {
        this.userService = new UserService();
    }
    
    @FXML
    public void initialize() {
        // Set up user type options
        userTypeComboBox.getItems().addAll("STUDENT", "ADMIN");
        userTypeComboBox.setValue("STUDENT");
        
        // Clear labels
        errorLabel.setText("");
        successLabel.setText("");
    }
    
    @FXML
    private void handleRegister() {
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();
        String userType = userTypeComboBox.getValue();
        
        // Validate input
        if (fullName.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please fill in all fields");
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            errorLabel.setText("Passwords do not match");
            return;
        }
        
        if (password.length() < 6) {
            errorLabel.setText("Password must be at least 6 characters");
            return;
        }
        
        // Check if username already exists
        if (userService.usernameExists(username)) {
            errorLabel.setText("Username already exists");
            return;
        }
        
        // Check if email already exists
        if (userService.emailExists(email)) {
            errorLabel.setText("Email already exists");
            return;
        }
        
        // Create new user
        User newUser = new User();
        newUser.setFullName(fullName);
        newUser.setEmail(email);
        newUser.setUsername(username);
        newUser.setPassword(password);
        newUser.setUserType(User.UserType.valueOf(userType));
        
        // Register user
        if (userService.registerUser(newUser)) {
            successLabel.setText("Registration successful! Please login.");
            errorLabel.setText("");
            
            // Clear fields
            clearFields();
        } else {
            errorLabel.setText("Registration failed. Please try again.");
        }
    }
    
    @FXML
    private void handleBack() {
        SceneManager.switchToScene("login");
    }
    
    private void clearFields() {
        fullNameField.clear();
        emailField.clear();
        usernameField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        userTypeComboBox.setValue("STUDENT");
    }
}