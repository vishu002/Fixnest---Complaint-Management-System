package Controllers;

import models.User;
import services.UserService;
import utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField usernameField;
    
    @FXML
    private PasswordField passwordField;
    
    @FXML
    private ComboBox<String> userTypeComboBox;
    
    @FXML
    private Label errorLabel;
    
    private UserService userService;
    
    public LoginController() {
        this.userService = new UserService();
    }
    
    @FXML
    public void initialize() {
        // Set up user type options
        userTypeComboBox.getItems().addAll("STUDENT", "ADMIN");
        userTypeComboBox.setValue("STUDENT");
        
        // Clear error label
        errorLabel.setText("");
    }
    
    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String userType = userTypeComboBox.getValue();
        
        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please enter both username and password");
            return;
        }
        
        // Attempt login
        User user = userService.loginUser(username, password);
        
        if (user != null) {
            // Check if user type matches
            if (user.getUserType().toString().equals(userType)) {
                // Store user in session
                SceneManager.putSessionData("currentUser", user);
                
                // Redirect based on user type
                if (userType.equals("ADMIN")) {
                    SceneManager.switchToScene("admin_dashboard");
                } else {
                    SceneManager.switchToScene("student_dashboard");
                }
            } else {
                errorLabel.setText("Invalid user type for this account");
            }
        } else {
            errorLabel.setText("Invalid username or password");
        }
    }
    
    @FXML
    private void handleRegister() {
        SceneManager.switchToScene("register");
    }
}