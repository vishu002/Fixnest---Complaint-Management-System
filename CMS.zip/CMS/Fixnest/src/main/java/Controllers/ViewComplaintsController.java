package Controllers;

import models.Complaint;
import services.ComplaintService;
import utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.util.List;

public class ViewComplaintsController {

    @FXML
    private TableView<Complaint> complaintsTable;
    
    @FXML
    private TableColumn<Complaint, Integer> idColumn;
    
    @FXML
    private TableColumn<Complaint, String> studentColumn;
    
    @FXML
    private TableColumn<Complaint, String> titleColumn;
    
    @FXML
    private TableColumn<Complaint, String> categoryColumn;
    
    @FXML
    private TableColumn<Complaint, String> statusColumn;
    
    @FXML
    private TableColumn<Complaint, String> dateColumn;
    
    @FXML
    private VBox complaintDetails;
    
    @FXML
    private Label detailStudent;
    
    @FXML
    private Label detailTitle;
    
    @FXML
    private Label detailDescription;
    
    @FXML
    private Label detailStatus;
    
    @FXML
    private TextArea adminNotesField;
    
    @FXML
    private Button pendingButton;
    
    @FXML
    private Button progressButton;
    
    @FXML
    private Button resolvedButton;
    
    @FXML
    private Button backButton;
    
    private ComplaintService complaintService;
    private ObservableList<Complaint> complaintsData;
    private Complaint selectedComplaint;
    
    public ViewComplaintsController() {
        this.complaintService = new ComplaintService();
        this.complaintsData = FXCollections.observableArrayList();
    }
    
    @FXML
    public void initialize() {
        // Set up table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        studentColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        
        // Load all complaints
        loadAllComplaints();
        
        // Set up table selection listener
        complaintsTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showComplaintDetails(newValue)
        );
        
        // Hide details initially
        complaintDetails.setVisible(false);
    }
    
    private void loadAllComplaints() {
        List<Complaint> complaints = complaintService.getAllComplaints();
        complaintsData.setAll(complaints);
        complaintsTable.setItems(complaintsData);
    }
    
    private void showComplaintDetails(Complaint complaint) {
        this.selectedComplaint = complaint;
        
        if (complaint != null) {
            detailStudent.setText("Student: " + complaint.getStudentName());
            detailTitle.setText("Title: " + complaint.getTitle());
            detailDescription.setText("Description: " + complaint.getDescription());
            detailStatus.setText("Status: " + complaint.getStatus().toString());
            
            // Set admin notes if available
            if (complaint.getAdminNotes() != null) {
                adminNotesField.setText(complaint.getAdminNotes());
            } else {
                adminNotesField.clear();
            }
            
            // Update button states based on current status
            updateButtonStates(complaint.getStatus());
            
            complaintDetails.setVisible(true);
        } else {
            complaintDetails.setVisible(false);
        }
    }
    
    private void updateButtonStates(Complaint.Status status) {
        // Enable/disable buttons based on current status
        pendingButton.setDisable(status == Complaint.Status.PENDING);
        progressButton.setDisable(status == Complaint.Status.IN_PROGRESS);
        resolvedButton.setDisable(status == Complaint.Status.RESOLVED);
    }
    
    @FXML
    private void handleStatusPending() {
        updateComplaintStatus(Complaint.Status.PENDING);
    }
    
    @FXML
    private void handleStatusInProgress() {
        updateComplaintStatus(Complaint.Status.IN_PROGRESS);
    }
    
    @FXML
    private void handleStatusResolved() {
        updateComplaintStatus(Complaint.Status.RESOLVED);
    }
    
    private void updateComplaintStatus(Complaint.Status newStatus) {
        if (selectedComplaint != null) {
            String adminNotes = adminNotesField.getText().trim();
            
            if (complaintService.updateComplaintStatus(
                selectedComplaint.getId(), newStatus, adminNotes)) {
                
                // Refresh the table
                loadAllComplaints();
                
                // Update details display
                showComplaintDetails(selectedComplaint);
                
                System.out.println("Complaint status updated to: " + newStatus);
            } else {
                System.out.println("Failed to update complaint status");
            }
        }
    }
    
    @FXML
    private void handleBack() {
        SceneManager.switchToScene("admin_dashboard");
    }
}