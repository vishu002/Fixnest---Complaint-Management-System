package Controllers;

import models.Complaint;
import models.User;
import services.ComplaintService;
import utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class ComplaintStatusController {

    @FXML
    private TableView<Complaint> complaintsTable;
    
    @FXML
    private TableColumn<Complaint, Integer> idColumn;
    
    @FXML
    private TableColumn<Complaint, String> titleColumn;
    
    @FXML
    private TableColumn<Complaint, String> categoryColumn;
    
    @FXML
    private TableColumn<Complaint, String> statusColumn;
    
    @FXML
    private TableColumn<Complaint, String> dateColumn;
    
    @FXML
    private VBox complaintDetails;
    
    @FXML
    private Label detailTitle;
    
    @FXML
    private Label detailDescription;
    
    @FXML
    private Label detailStatus;
    
    @FXML
    private Label detailAdminNotes;
    
    @FXML
    private Button backButton;
    
    private ComplaintService complaintService;
    private User currentUser;
    private ObservableList<Complaint> complaintsData;
    
    public ComplaintStatusController() {
        this.complaintService = new ComplaintService();
        this.complaintsData = FXCollections.observableArrayList();
    }
    
    @FXML
    public void initialize() {
        // Get current user from session
        currentUser = (User) SceneManager.getSessionData("currentUser");
        
        if (currentUser == null) {
            SceneManager.switchToScene("login");
            return;
        }
        
        // Set up table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        
        // Load complaints
        loadComplaints();
        
        // Set up table selection listener
        complaintsTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showComplaintDetails(newValue)
        );
        
        // Hide details initially
        complaintDetails.setVisible(false);
    }
    
    private void loadComplaints() {
        List<Complaint> complaints = complaintService.getComplaintsByStudent(currentUser.getId());
        complaintsData.setAll(complaints);
        complaintsTable.setItems(complaintsData);
    }
    
    private void showComplaintDetails(Complaint complaint) {
        if (complaint != null) {
            detailTitle.setText("Title: " + complaint.getTitle());
            detailDescription.setText("Description: " + complaint.getDescription());
            detailStatus.setText("Status: " + complaint.getStatus().toString());
            
            String adminNotes = complaint.getAdminNotes();
            if (adminNotes != null && !adminNotes.isEmpty()) {
                detailAdminNotes.setText("Admin Notes: " + adminNotes);
            } else {
                detailAdminNotes.setText("Admin Notes: No notes available");
            }
            
            complaintDetails.setVisible(true);
        } else {
            complaintDetails.setVisible(false);
        }
    }
    
    @FXML
    private void handleBack() {
        SceneManager.switchToScene("student_dashboard");
    }
}