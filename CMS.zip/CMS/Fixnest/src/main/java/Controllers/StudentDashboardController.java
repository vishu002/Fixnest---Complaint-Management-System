package Controllers;

import models.User;
import utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class StudentDashboardController {

    @FXML
    private Label welcomeLabel;
    
    private User currentUser;
    
    @FXML
    public void initialize() {
        // Get current user from session
        currentUser = (User) SceneManager.getSessionData("currentUser");
        
        if (currentUser != null) {
            welcomeLabel.setText("Welcome, " + currentUser.getFullName() + "!");
        } else {
            // If no user in session, go back to login
            SceneManager.switchToScene("login");
        }
    }
    
    @FXML
    private void handleProfile() {
        // Show profile information in main content area
        // You can implement this to show user details
        System.out.println("Profile button clicked");
    }
    
    @FXML
    private void handleComplaintForm() {
        SceneManager.switchToScene("complaint_form");
    }
    
    @FXML
    private void handleComplaintStatus() {
        SceneManager.switchToScene("complaint_status");
    }
    
    @FXML
    private void handleLogout() {
        // Clear session data
        SceneManager.clearSession();
        // Go back to login
        SceneManager.switchToScene("login");
    }
}