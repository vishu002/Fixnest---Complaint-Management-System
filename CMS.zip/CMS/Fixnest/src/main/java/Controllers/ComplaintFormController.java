package Controllers;

import models.Complaint;
import models.User;
import services.ComplaintService;
import utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ComplaintFormController {

    @FXML
    private TextField titleField;
    
    @FXML
    private ComboBox<String> categoryComboBox;
    
    @FXML
    private TextArea descriptionField;
    
    @FXML
    private Label messageLabel;
    
    private ComplaintService complaintService;
    private User currentUser;
    
    public ComplaintFormController() {
        this.complaintService = new ComplaintService();
    }
    
    @FXML
    public void initialize() {
        // Get current user from session
        currentUser = (User) SceneManager.getSessionData("currentUser");
        
        if (currentUser == null) {
            SceneManager.switchToScene("login");
            return;
        }
        
        // Set up complaint categories
        categoryComboBox.getItems().addAll(
            "Academic",
            "Hostel",
            "Library", 
            "Cafeteria",
            "Sports",
            "Infrastructure",
            "Administrative",
            "Other"
        );
        categoryComboBox.setValue("Academic");
        
        // Clear message label
        messageLabel.setText("");
    }
    
    @FXML
    private void handleSubmit() {
        String title = titleField.getText().trim();
        String category = categoryComboBox.getValue();
        String description = descriptionField.getText().trim();
        
        // Validate input
        if (title.isEmpty() || description.isEmpty()) {
            messageLabel.setText("Please fill in all fields");
            messageLabel.setStyle("-fx-text-fill: red;");
            return;
        }
        
        if (title.length() < 5) {
            messageLabel.setText("Title must be at least 5 characters");
            messageLabel.setStyle("-fx-text-fill: red;");
            return;
        }
        
        if (description.length() < 10) {
            messageLabel.setText("Description must be at least 10 characters");
            messageLabel.setStyle("-fx-text-fill: red;");
            return;
        }
        
        // Create complaint object
        Complaint complaint = new Complaint();
        complaint.setStudentId(currentUser.getId());
        complaint.setTitle(title);
        complaint.setCategory(category);
        complaint.setDescription(description);
        complaint.setStatus(Complaint.Status.PENDING);
        
        // Submit complaint
        if (complaintService.createComplaint(complaint)) {
            messageLabel.setText("Complaint submitted successfully!");
            messageLabel.setStyle("-fx-text-fill: green;");
            clearFields();
        } else {
            messageLabel.setText("Failed to submit complaint. Please try again.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }
    
    @FXML
    private void handleBack() {
        SceneManager.switchToScene("student_dashboard");
    }
    
    private void clearFields() {
        titleField.clear();
        categoryComboBox.setValue("Academic");
        descriptionField.clear();
    }
}