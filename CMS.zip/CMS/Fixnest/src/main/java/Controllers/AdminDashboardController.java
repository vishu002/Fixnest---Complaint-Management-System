package Controllers;

import models.User;
import utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class AdminDashboardController {

    @FXML
    private Label welcomeLabel;
    
    private User currentUser;
    
    @FXML
    public void initialize() {
        // Get current user from session
        currentUser = (User) SceneManager.getSessionData("currentUser");
        
        if (currentUser != null && currentUser.getUserType() == User.UserType.ADMIN) {
            welcomeLabel.setText("Welcome, Admin " + currentUser.getFullName() + "!");
        } else {
            // If no admin user in session, go back to login
            SceneManager.switchToScene("login");
        }
    }
    
    @FXML
    private void handleViewComplaints() {
        SceneManager.switchToScene("view_complaints");
    }
    
    @FXML
    private void handleManageUsers() {
        // You can implement user management functionality here
        System.out.println("Manage Users clicked - Feature to be implemented");
        // SceneManager.switchToScene("manage_users");
    }
    
    @FXML
    private void handleLogout() {
        // Clear session data
        SceneManager.clearSession();
        // Go back to login
        SceneManager.switchToScene("login");
    }
}