module com.cms.fixnest {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    
    opens com.cms.fixnest to javafx.fxml;
    opens Controllers to javafx.fxml;
    opens models to javafx.base;
    
    exports com.cms.fixnest;
    exports Controllers;
    exports models;
}