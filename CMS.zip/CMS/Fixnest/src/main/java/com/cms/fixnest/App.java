package com.cms.fixnest;

import com.cms.fixnest.config.DatabaseConfig;
import utils.SceneManager;
import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage stage) {
        try {
            System.out.println("=== Application Starting ===");
            
            // Test database (but don't block startup)
            new Thread(() -> {
                System.out.println("Testing database connection in background...");
                DatabaseConfig.testConnection();
            }).start();
            
            // Initialize SceneManager
            SceneManager.setPrimaryStage(stage);
            System.out.println("SceneManager initialized");
            
            // Configure main window
            stage.setTitle("Fixnest - Complaint Management System");
            stage.setResizable(false);
            System.out.println("Stage configured");
            
            // Start with login screen
            SceneManager.switchToScene("login");
            System.out.println("Login scene loaded");
            
            stage.show();
            System.out.println("=== Application Started Successfully ===");
            
        } catch (Exception e) {
            System.err.println("Fatal error during application startup:");
            e.printStackTrace();
            
            // Show error dialog
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Application Error");
            alert.setHeaderText("Failed to start application");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        try {
            System.out.println("Launching JavaFX application...");
            launch(args);
        } catch (Exception e) {
            System.err.println("Failed to launch application:");
            e.printStackTrace();
        }
    }
}