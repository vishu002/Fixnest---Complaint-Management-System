package utils;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class SceneManager {
    private static Stage primaryStage;
    private static final Map<String, Object> sessionData = new HashMap<>();
    
    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }
    
    public static void switchToScene(String fxmlFile) {
        try {
            System.out.println("Loading FXML: " + fxmlFile);
            
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource("/" + fxmlFile + ".fxml"));
            Parent root = loader.load();
            System.out.println("FXML loaded successfully: " + fxmlFile);
            
            Scene scene = new Scene(root, 900, 600);
            System.out.println("Scene created");
            
            // Try to load CSS but don't crash if it fails
            try {
                String cssPath = SceneManager.class.getResource("/com/cms/fixnest/css/style.css").toExternalForm();
                scene.getStylesheets().add(cssPath);
                System.out.println("CSS loaded successfully");
            } catch (Exception e) {
                System.out.println("CSS not loaded: " + e.getMessage());
                // Continue without CSS
            }
            
            primaryStage.setScene(scene);
            System.out.println("Scene set on stage");
            
        } catch (IOException e) {
            System.err.println("Error loading FXML file: " + fxmlFile);
            e.printStackTrace();
            
            // Show a simple error scene
            showErrorScene("Cannot load interface: " + fxmlFile);
        } catch (Exception e) {
            System.err.println("Unexpected error loading scene: " + fxmlFile);
            e.printStackTrace();
            showErrorScene("Unexpected error: " + e.getMessage());
        }
    }
    
    private static void showErrorScene(String message) {
        try {
            // Create a simple error scene
            javafx.scene.control.Label errorLabel = new javafx.scene.control.Label(message);
            javafx.scene.layout.StackPane root = new javafx.scene.layout.StackPane(errorLabel);
            Scene errorScene = new Scene(root, 600, 400);
            primaryStage.setScene(errorScene);
        } catch (Exception e) {
            System.err.println("Even error scene failed: " + e.getMessage());
        }
    }
    
    public static void putSessionData(String key, Object value) {
        sessionData.put(key, value);
    }
    
    public static Object getSessionData(String key) {
        return sessionData.get(key);
    }
    
    public static void clearSession() {
        sessionData.clear();
    }
    
    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}